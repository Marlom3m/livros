<?php
	require_once('../config.php');
	require_once(DBAPI);

	if(!empty($_GET['nome'])){
		$estudantes = array();
		$nome = $_GET['nome'];
		$resultados = findList('estudante','nome',$nome);
		if($resultados){
			foreach ($resultados as $resultado){
				$estudante = new Estudante;
				$estudante->id = $resultado['id'];
				$estudante->label = $resultado['nome']." - RGA:".$resultado['rga'];
				$estudante->value = $resultado['nome']." - RGA:".$resultado['rga'];
				array_push($estudantes,$estudante);
			}
		}
		echo json_encode($estudantes);
	}

	class Estudante{
		public $id;
		public $label;
		public $value;
	}
?>