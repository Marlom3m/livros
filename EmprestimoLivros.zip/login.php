<?php
	require_once('config.php');
	require_once(DBAPI);
	
	if(!empty($_POST['siape'])){
		$id = $_POST['siape'];
		$servidor = find('servidor', $id);
		if(!empty($servidor['id'])){
			session_start();
			$_SESSION['number']=$servidor['id'];
			$_SESSION['user']=$servidor['nome'];
		}
	}
	header("Location: index.php");exit;
?>