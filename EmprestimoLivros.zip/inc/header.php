<!DOCTYPE html>	
<html>	
	<head>	    
		<meta charset="utf-8">	    	    
		<title>Livros</title>	    
		<meta name="description" content="">	    
		<meta name="viewport" content="width=device-width, initial-scale=1">	
		<link rel="stylesheet" href="<?php echo BASEURL; ?>cdn/css/bootstrap.css">
		<link rel="stylesheet" href="<?php echo BASEURL; ?>cdn/css/jquery-ui.css"> 
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>	
	</head>	
	<body>
		<nav class="navbar navbar-expand-sm bg-dark navbar-dark">	       	          
			<a href="<?php echo BASEURL; ?>index.php" class="navbar-brand">INÍCIO</a>
			<?php
			if(!isset($_SESSION)){
				session_start();
			}
			if(empty($_SESSION['number'])){
			?>
			<ul class="navbar-nav navbar-collapse">          	            
				<li class="nav-item">	                
					<a href="#" class="nav-link disabled">	                    
						Gerenciar Livros                
					</a>									
				</li>
				<li class="nav-item" >	                
					<a href="#" class="nav-link disabled">	                    
						Gerenciar Estudantes                
					</a>									
				</li>
				<li class="nav-item">	                
					<a href="#" class="nav-link disabled">	                    
						Gerenciar Servidor               
					</a>									
				</li>
			</ul>
			<button type="button" class="btn btn-default" data-toggle="modal" data-target="#login-modal">Login</button>
			
			<?php 
				} else {
			?>	             
			<ul class="navbar-nav navbar-collapse">          	            
				<li class="nav-item">	                
					<a href="<?php echo BASEURL; ?>livro/index.php" class="nav-link">	                    
						Gerenciar Livros                
					</a>									
				</li>
				<li class="nav-item" >	                
					<a href="<?php echo BASEURL; ?>estudante/index.php" class="nav-link">	                    
						Gerenciar Estudantes                
					</a>									
				</li>
				<li class="nav-item">	                
					<a href="<?php echo BASEURL; ?>servidor/index.php" class="nav-link">	                    
						Gerenciar Servidor               
					</a>									
				</li>		
			</ul>
			<span class="navbar-text"> <?php echo "Olá, ".$_SESSION['user']; ?> </span>
			<a href="<?php echo BASEURL;?>logout.php" class="btn text-primary">Logout</a>
			<?php 
				}
			?>		
		</nav>	
    <main class="container">
