		</main> <!-- /container -->	
		<hr>		
			<footer class="container">			
				<p>IFMS</p>		
			</footer>
			<?php include(ABSPATH.'modalLogin.php'); ?>
			<script src="<?php echo BASEURL; ?>cdn/jquery/dist/jquery.slim.js"></script>
			<script src="../cdn/js/jquery-ui.js" type="text/javascript"></script>
			<script src="<?php echo BASEURL; ?>cdn/popper.js/dist/popper.js"></script> 
			<script src="<?php echo BASEURL; ?>cdn/js/bootstrap.js"></script>
			
	</body>	
</html>