<?php	
	require_once('../config.php');
	require_once(DBAPI);
	$servidores = null;
	$servidor = null;		
	session_start();
	/**	 *  Listagem dos servidores	 */	
	function index() {		
		global $servidores;		
		$servidores = find_all('servidor');	
	}
	
	function testeSiape($servidor){
		if(empty($servidor["'id'"])){
			$_SESSION['type'] = "danger";
			$_SESSION['msgId'] = "Preencha o SIAPE";
			return false;
		}
		return true;		
	}
	
	function testeNome($servidor){
		if(empty($servidor["'nome'"])){
			$_SESSION['type'] = "danger";
			$_SESSION['msgNome'] = "Preencha o nome";
			return false;
		}
		return true;		
	}
	
	function add() {		  
		if (!empty($_POST['servidor'])) {	    	    		    
			$servidor = $_POST['servidor'];
			$teste1 = testeSiape($servidor);
			$teste2 = testeNome($servidor);
			if($teste1 && $teste2){
				save('servidor', $servidor);
			}			
			header('location: add.php');exit;	  
		}
	}
	
	function edit() {		  	  	    
		if (isset($_GET['id'])) {		    
			$id = $_GET['id'];		    
			if (isset($_POST['servidor'])) {		      
				$servidor = $_POST['servidor'];
				if(testeNome($servidor)){				
					update('servidor', $id, $servidor);
					header('location: servidores.php');exit;
				} else {
					header('location: edit.php?id='.$id);exit;
				}
					
			} else {		      
				global $servidor;	      
				$servidor = find('servidor', $id);	    
			} 	  
		} else {	    
			header('location: servidores.php');exit;	  
		}			   	
	}
	
	function view($id = null) {	  
		global $servidor;	  
		$servidor = find('servidor', $id);	
	}
	
	function delete($id = null) {		  
		global $servidor;	  
		$servidor = remove('servidor', $id);		  
		header('location: servidores.php');	exit;
	}
?>