<?php
	require_once('config.php');
	session_start();
	session_unset();
	echo 'Location: '.ABSPATH.'index.php';
	header('Location: '.BASEURL.'index.php');exit;


?>