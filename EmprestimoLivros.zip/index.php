<?php require_once 'config.php'; ?>	
<?php require_once DBAPI; ?>	
<?php include(HEADER_TEMPLATE); ?>	
<?php $db = open_database(); ?>	
	<div class="container">
		<h1 class="text-center">GERENCIADOR DE ENTREGA DOS LIVROS</h1>
	</div>
	<div class="container">
		<div class = "col">
			<div class = "card">
	<?php if(empty($_SESSION['number'])){ ?>
	<div class="container">
		<h2 class="text-center text-danger">Realize o Login</h2>
	</div>
	
	<?php } ?>	
	<?php 
		if ($db) { 
			if(!empty($_SESSION['number'])){
	?>
			<a href="emprestimo/index.php" class="btn btn-success">
				<div class="col-xs-12 text-center">
					<i class="fa fa-book fa-5x"></i>
				</div>
				<div class="col-xs-12 text-center">
					Entregar Livro
				</div>
			</a>
	<?php } else { ?>		
			<a href="" class="btn btn-success disabled">
				<div class="col-xs-12 text-center">
					<i class="fa fa-book fa-5x"></i>
				</div>
				<div class="col-xs-12 text-center">
					Entregar Livros
				</div>
			</a>
	<?php } ?>
			<a href="" class="btn btn-info disabled">
				<div class="col-xs-12 text-center">
					<i class="fa fa-search fa-5x"></i>
				</div>
				<div class="col-xs-12 text-center">
					Consulta Livros Entregues
				</div>
			</a>
				
			<a href="" class="btn btn-warning disabled">
				<div class="col-xs-12 text-center">
					<i class="fa fa-book fa-5x"></i>
				</div>
				<div class="col-xs-12 text-center">
					Devolução de Livros
				</div>
			</a>
	
	<?php }else{ ?>	
			<div class="alert alert-danger" role="alert">			
			<p><strong>ERRO:</strong> Não foi possível Conectar ao Banco de Dados!</p>		
			</div>
			
<?php } ?>

			
			</div>
		</div>
	</div>
<?php include(FOOTER_TEMPLATE); ?>

