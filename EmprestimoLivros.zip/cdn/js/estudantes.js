function deletar(id){
	$("#confirm").attr("href","delete.php?id="+id);
}

	
